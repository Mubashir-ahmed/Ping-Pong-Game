# Ping Pong Game - CP Project
-------------------------------

- On Ubuntu/other linux distributions:
  Open a Terminal and type:

      git clone https://github.com/Rofey/Ping-Pong
      g++ main.cpp -lsfml-graphics -lsfml-audio -lsfml-window -lsfml-systrem

- On Windows
  Open a command prompt and type in:

      git clone https://github.com/Rofey/Ping-Pong
      g++ main.cpp -lsfml-graphics -lsfml-audio -lsfml-window -lsfml-systrem


Features:
- Game uses OOP concepts
- SFML/Graphics library for Game Engine or Graphics

Known issues:
Keys can be sticky.

K17-3746
Muhammad Rafay
